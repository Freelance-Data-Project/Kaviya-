// Meta Pixel Subscribe event: fires when a visitor clicks either Telegram button.
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll("[data-subscribe]").forEach(function (button) {
    button.addEventListener("click", function () {
      if (typeof window.fbq === "function") {
        window.fbq("track", "Subscribe");
      }
    });
  });
});
