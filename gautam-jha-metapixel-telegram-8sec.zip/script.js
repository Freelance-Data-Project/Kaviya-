document.querySelectorAll('a[href*="t.me/+2CfR4-D5Fkk2ODBl"]').forEach(function(link){
  link.addEventListener('click', function(){});
});
